from flask import Flask, request, jsonify

app = Flask(__name__)

# FARMER DATA FOR LOAN APPROVALS
FARMER_DATA = {
    "Ammar": {"previous_loans": 2, "repayment_rate": 0.9},
    "Shayan": {"previous_loans": 1, "repayment_rate": 0.7},
    "Sufyan": {"previous_loans": 3, "repayment_rate": 0.6}
}

# SAMPLE SEED SUPPLIERS WITH RATINGS
SEED_SUPPLIERS = {
    "AgriSeeds": 4.2,
    "GreenGrow": 4.0,
    "FarmBest": 3.8
}

# SAMPLE FERTILIZER SUPPLIERS
FERTILIZER_SUPPLIERS = {
    "AgriFert": 4.5,
    "NutriFarms": 4.3
}

# SAMPLE TRANSPORT COMPANIES WITH RATINGS
TRANSPORT_COMPANIES = {
    "QuickTrans": 4.1,
    "AgriMove": 3.9
}

# CROP ADVISORY SERVICE
@app.route('/crop_advisor', methods=['GET'])
def crop_advisor():
    city = request.args.get('city')
    crop = request.args.get('crop')

    if not city or not crop:
        return jsonify({"error": "City and crop parameters are required"}), 400

    # Static Weather Data
    temp = 25  
    humidity = 60  

    # Simple Logic for Weather
    if 15 <= temp <= 30 and 50 <= humidity <= 80:
        return jsonify({"decision": "approved", "reason": "Weather conditions are suitable for {crop}."})
    else:
        return jsonify({"decision": "not approved", "reason": f"Weather is not suitable for {crop}."})

# BANK LOAN APPROVAL SERVICE
@app.route('/bank_loan', methods=['GET'])
def bank_loan():
    farmer_name = request.args.get('farmer')

    if not farmer_name:
        return jsonify({"error": "Farmer name is required"}), 400

    farmer = FARMER_DATA.get(farmer_name)

    if not farmer:
        return jsonify({"error": "Farmer not found"}), 404

    trust_factor = (farmer["repayment_rate"] * 0.7) + (farmer["previous_loans"] * 0.3)
    loan_approved = trust_factor >= 0.7

    return jsonify({
        "loan_approved": loan_approved,
        "trust_factor": round(trust_factor, 2)
    })

# SEED PROCUREMENT SERVICE
@app.route('/seed_procure', methods=['POST'])
def seed_procure():
    data = request.get_json()
    company = data.get("company")

    if company in SEED_SUPPLIERS:
        return jsonify({
            "status": "success",
            "message": f"Order placed with {company}.",
            "rating": SEED_SUPPLIERS[company]
        })
    else:
        return jsonify({"status": "failed", "message": "Invalid seed company."})

# FERTILIZER PROCUREMENT SERVICE
@app.route('/fertilizer_procure', methods=['POST'])
def fertilizer_procure():
    data = request.get_json()
    supplier = data.get("supplier")

    if supplier in FERTILIZER_SUPPLIERS:
        return jsonify({
            "status": "success",
            "message": f"Order placed with {supplier}.",
            "rating": FERTILIZER_SUPPLIERS[supplier]
        })
    else:
        return jsonify({"status": "failed", "message": "Invalid fertilizer supplier."})

# TRANSPORT SERVICE
@app.route('/transport_arrange', methods=['POST'])
def transport_arrange():
    data = request.get_json()
    company = data.get("company")

    if company in TRANSPORT_COMPANIES:
        return jsonify({
            "status": "success",
            "message": f"Transport arranged with {company}.",
            "rating": TRANSPORT_COMPANIES[company]
        })
    else:
        return jsonify({"status": "failed", "message": "Invalid transport company."})

# SMART AGRICULTURE SERVICE (INTEGRATED SERVICE)
@app.route('/smart_agriculture', methods=['POST'])
def smart_agriculture():
    """Integrated endpoint to process multiple requests in one call."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    def safe_call(func, json_data=None, args_data=None):
        """Helper function to call services safely and handle errors."""
        try:
            with app.test_request_context(json=json_data, query_string=args_data):
                return func().get_json()
        except Exception as e:
            return {"error": str(e)}

    # Processing Crop Advisory
    crop_type = data.get("crop", "")
    crop_response = safe_call(crop_advisor, args_data={"crop": crop_type})

    # Processing Loan Approval
    farmer_name = data.get("farmer", "")
    loan_response = safe_call(bank_loan, args_data={"farmer": farmer_name})

    # Processing Seed Procurement
    seed_company = data.get("seed_company")
    seed_response = safe_call(seed_procure, json_data={"company": seed_company}) if seed_company else {"status": "skipped"}

    # Processing Fertilizer Procurement
    fertilizer_supplier = data.get("fertilizer_supplier")
    fertilizer_response = safe_call(fertilizer_procure, json_data={"supplier": fertilizer_supplier}) if fertilizer_supplier else {"status": "skipped"}

    # Processing Transport Arrangement
    transport_company = data.get("transport_company")
    transport_response = safe_call(transport_arrange, json_data={"company": transport_company}) if transport_company else {"status": 
    "skipped"}

    # Returning Combined Responses
    return jsonify({
        "crop_advisory": crop_response,
        "bank_loan": loan_response,
        "seed_procurement": seed_response,
        "fertilizer_procurement": fertilizer_response,
        "transport_arrangement": transport_response
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
