import requests

def get_crop_health(city, crop):
    url = 'http://127.0.0.1:5000/crop_health' 
    params = {'city': city, 'crop': crop}

    response = requests.get(url, params=params)

    if response.status_code == 200:
        health_data = response.json()
        print(f"\nCity: {health_data['city']}")
        print(f"Crop: {health_data['crop'].capitalize()}")
        print(f"Temperature: {health_data['current_temp']}°C ({health_data['temp_status']})")
        print(f"Humidity: {health_data['current_humidity']}% ({health_data['humidity_status']})")
        print(f"Pressure: {health_data['current_pressure']} hPa ({health_data['pressure_status']})")
        print(f"Overall Health: {health_data['overall_health']}")
    else:
        error_message = response.json().get('error', 'Unknown error occurred')
        print(f"Error: {error_message}")

if __name__ == "__main__":
    city_name = input("Enter city name: ")
    crop_type = input("Enter crop type (wheat, corn, rice, cotton): ")
    get_crop_health(city_name, crop_type)
